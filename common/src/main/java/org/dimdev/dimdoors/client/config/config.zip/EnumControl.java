package org.dimdev.dimdoors.client.config;

import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public final class EnumControl extends AbstractConfigControl {
    private Enum<?> value;

    public EnumControl(ConfigControlRegistry registry, OptionInfo option) {
        super(registry, option);
        this.value = (Enum<?>) option.value();
    }

    @Override
    public int rowCount() {
        return 1;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addRows(ControlHost host, RowCursor cursor) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            return;
        }

        host.addLabel(this.option.label(host), host.labelX(), y + 6, 0xE0E0E0);

        Class<? extends Enum> enumClass = this.option.type().asSubclass(Enum.class);
        List<Enum> values = Arrays.stream(enumClass.getEnumConstants()).map(Enum.class::cast).toList();

        if (this.value == null && !values.isEmpty()) {
            this.value = values.get(0);
        }

        CycleButton<Enum> button = CycleButton.<Enum>builder(EnumControl::enumLabel)
                .withValues(values)
                .withInitialValue((Enum) this.value)
                .displayOnlyValue()
                .create(host.valueX(), y, host.valueWidth(), 20, this.option.label(host), (ignored, newValue) -> this.value = newValue);

        host.addTooltip(button, this.option.tooltipKey());
        host.addWidget(button);
    }

    @Override
    public boolean validate() {
        return this.value != null;
    }

    @Override
    public void commit() {
        this.option.setValue(this.value);
    }

    private static Component enumLabel(Enum<?> value) {
        try {
            Method method = value.getClass().getMethod("getKey");
            Object result = method.invoke(value);

            if (result instanceof Component component) {
                return component;
            }

            if (result instanceof String key) {
                return Component.translatable(key);
            }
        } catch (ReflectiveOperationException ignored) {
        }

        return Component.literal(value.name());
    }
}
