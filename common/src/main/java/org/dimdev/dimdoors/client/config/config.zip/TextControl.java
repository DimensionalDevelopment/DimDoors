package org.dimdev.dimdoors.client.config;

import net.minecraft.client.gui.components.EditBox;

import java.util.function.Function;
import java.util.function.Predicate;

public final class TextControl extends AbstractConfigControl {
    private final Predicate<String> validator;
    private final Function<String, Object> parser;
    private String text;
    private EditBox visibleBox;

    private TextControl(ConfigControlRegistry registry, OptionInfo option, String text, Predicate<String> validator, Function<String, Object> parser) {
        super(registry, option);
        this.text = text;
        this.validator = validator;
        this.parser = parser;
    }

    public static TextControl integer(ConfigControlRegistry registry, OptionInfo option) {
        Object value = option.value();
        return new TextControl(registry, option, value == null ? "0" : Integer.toString((Integer) value), TextControl::isInt, text -> Integer.parseInt(text.trim()));
    }

    public static TextControl floatingPoint(ConfigControlRegistry registry, OptionInfo option) {
        Object value = option.value();
        return new TextControl(registry, option, value == null ? "0.0" : Float.toString((Float) value), TextControl::isFloat, text -> Float.parseFloat(text.trim()));
    }

    public static TextControl decimal(ConfigControlRegistry registry, OptionInfo option) {
        Object value = option.value();
        return new TextControl(registry, option, value == null ? "0.0" : Double.toString((Double) value), TextControl::isDouble, text -> Double.parseDouble(text.trim()));
    }

    public static TextControl string(ConfigControlRegistry registry, OptionInfo option) {
        Object value = option.value();
        return new TextControl(registry, option, value == null ? "" : value.toString(), ignored -> true, text -> text);
    }

    @Override
    public int rowCount() {
        return 1;
    }

    @Override
    public void addRows(ControlHost host, RowCursor cursor) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            this.visibleBox = null;
            return;
        }

        host.addLabel(this.option.label(host), host.labelX(), y + 6, 0xE0E0E0);

        EditBox editBox = new EditBox(host.font(), host.valueX(), y, host.valueWidth(), 20, this.option.label(host));
        editBox.setValue(this.text);
        editBox.setMaxLength(1024);
        editBox.setResponder(value -> {
            this.text = value;
            host.validateAll();
        });

        this.visibleBox = editBox;
        host.addTooltip(editBox, this.option.tooltipKey());
        host.addWidget(editBox);
    }

    @Override
    public boolean validate() {
        boolean valid = this.validator.test(this.text);

        if (this.visibleBox != null) {
            this.visibleBox.setTextColor(valid ? 0xE0E0E0 : 0xFF5555);
        }

        return valid;
    }

    @Override
    public void commit() {
        this.option.setValue(this.parser.apply(this.text));
    }

    private static boolean isInt(String value) {
        try {
            Integer.parseInt(value.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isFloat(String value) {
        try {
            Float.parseFloat(value.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isDouble(String value) {
        try {
            Double.parseDouble(value.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
