package org.dimdev.dimdoors.client.config;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;

import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public final class CollectionControl extends AbstractConfigControl {
    private final boolean set;
    private final Type elementType;
    private final Class<?> elementClass;
    private final List<Entry> entries = new ArrayList<>();
    private boolean expanded;

    private CollectionControl(ConfigControlRegistry registry, OptionInfo option, boolean set) {
        super(registry, option);
        this.set = set;
        this.elementType = elementType(option.genericType());
        this.elementClass = rawClass(this.elementType);

        Object value = option.value();
        if (value instanceof Collection<?> collection) {
            int index = 0;
            for (Object entry : collection) {
                this.entries.add(createEntry(index++, entry));
            }
        }
    }

    public static CollectionControl list(ConfigControlRegistry registry, OptionInfo option) {
        return new CollectionControl(registry, option, false);
    }

    public static CollectionControl set(ConfigControlRegistry registry, OptionInfo option) {
        return new CollectionControl(registry, option, true);
    }

    @Override
    public int rowCount() {
        if (!this.expanded) {
            return 1;
        }

        int rows = 2;
        for (Entry entry : this.entries) {
            rows += 1 + entry.control.rowCount();
        }
        return rows;
    }

    @Override
    public void addRows(ControlHost host, RowCursor cursor) {
        addHeaderRow(host, cursor);

        if (!this.expanded) {
            return;
        }

        for (int i = 0; i < this.entries.size(); i++) {
            addEntryHeaderRow(host, cursor, i);
            this.entries.get(i).control.addRows(host, cursor);
        }

        addAddRow(host, cursor);
    }

    @Override
    public boolean validate() {
        boolean valid = true;
        Set<Object> seen = new HashSet<>();

        for (Entry entry : this.entries) {
            boolean entryValid = entry.control.validate();

            if (entryValid) {
                try {
                    entry.control.commit();
                } catch (RuntimeException e) {
                    entryValid = false;
                }
            }

            if (this.set && entryValid && !seen.add(normalizeForSet(entry.value))) {
                entryValid = false;
            }

            valid &= entryValid;
        }

        return valid;
    }

    @Override
    public void commit() {
        for (Entry entry : this.entries) {
            entry.control.commit();
        }

        this.option.setValue(this.set ? createSetValue() : createListValue());
    }

    private void addHeaderRow(ControlHost host, RowCursor cursor) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            return;
        }

        host.addLabel(this.option.label(host), host.labelX(), y + 6, 0xE0E0E0);

        Component message = Component.literal((this.expanded ? "Collapse" : "Expand") + " (" + this.entries.size() + ")");
        Button button = Button.builder(message, ignored -> {
                    this.expanded = !this.expanded;
                    host.rebuild();
                })
                .bounds(host.valueX(), y, host.valueWidth(), 20)
                .build();

        host.addTooltip(button, this.option.tooltipKey());
        host.addWidget(button);
    }

    private void addEntryHeaderRow(ControlHost host, RowCursor cursor, int index) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            return;
        }

        host.addLabel(Component.literal("#" + (index + 1)), host.labelX() + 12, y + 6, 0xAAAAAA);

        Button remove = Button.builder(Component.literal("Remove"), ignored -> {
                    this.entries.remove(index);
                    rebuildEntryControls();
                    host.rebuild();
                })
                .bounds(host.valueX(), y, host.valueWidth(), 20)
                .build();

        host.addWidget(remove);
    }

    private void addAddRow(ControlHost host, RowCursor cursor) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            return;
        }

        Button add = Button.builder(Component.literal("+ Add"), ignored -> {
                    this.entries.add(createEntry(this.entries.size(), createDefaultElement()));
                    this.expanded = true;
                    host.rebuild();
                })
                .bounds(host.valueX(), y, host.valueWidth(), 20)
                .build();

        host.addWidget(add);
    }

    private Object createListValue() {
        List<Object> values = new ArrayList<>();
        for (Entry entry : this.entries) {
            values.add(entry.value);
        }

        if (this.option.type() == LinkedList.class) {
            return new LinkedList<>(values);
        }

        return new ArrayList<>(values);
    }

    private Object createSetValue() {
        Set<Object> values = this.option.type() == HashSet.class ? new HashSet<>() : new LinkedHashSet<>();
        for (Entry entry : this.entries) {
            values.add(entry.value);
        }
        return values;
    }

    private Entry createEntry(int index, Object value) {
        Entry entry = new Entry(value);
        entry.control = createEntryControl(index, entry);
        return entry;
    }

    private ConfigControl createEntryControl(int index, Entry entry) {
        Class<?> type = this.elementClass == Object.class && entry.value != null ? entry.value.getClass() : this.elementClass;
        Type genericType = this.elementType == Object.class && entry.value != null ? entry.value.getClass() : this.elementType;
        String key = this.option.key() + "[" + index + "]";

        OptionInfo entryOption = OptionInfo.value(
                key,
                type,
                genericType,
                () -> entry.value,
                value -> entry.value = value,
                Component.literal("#" + (index + 1)),
                this.option.tooltipKey()
        );

        return this.registry.create(entryOption);
    }

    private void rebuildEntryControls() {
        for (int i = 0; i < this.entries.size(); i++) {
            Entry entry = this.entries.get(i);
            entry.control = createEntryControl(i, entry);
        }
    }

    private Object createDefaultElement() {
        if (this.elementClass == String.class || this.elementClass == Object.class) {
            return "";
        }

        if (this.elementClass == Integer.class) {
            return 0;
        }

        if (this.elementClass == Float.class) {
            return 0.0F;
        }

        if (this.elementClass == Double.class) {
            return 0.0D;
        }

        if (this.elementClass == Boolean.class) {
            return false;
        }

        if (ResourceKey.class.isAssignableFrom(this.elementClass)) {
            return null;
        }

        if (this.elementClass.isEnum()) {
            Object[] constants = this.elementClass.getEnumConstants();
            return constants.length == 0 ? null : constants[0];
        }

        if (ConfigReflection.isExpandableConfigObjectType(this.elementClass)) {
            return createDefaultObject(this.elementClass);
        }

        return null;
    }

    private static Object createDefaultObject(Class<?> type) {
        try {
            Constructor<?> constructor = type.getDeclaredConstructor();
            constructor.setAccessible(true);
            return constructor.newInstance();
        } catch (ReflectiveOperationException e) {
            throw new IllegalArgumentException("Cannot create collection element: " + type.getName(), e);
        }
    }

    private static Object normalizeForSet(Object value) {
        if (value instanceof ResourceKey<?> key) {
            return key.location();
        }

        return value;
    }

    private static Type elementType(Type collectionType) {
        if (!(collectionType instanceof ParameterizedType parameterizedType)) {
            return Object.class;
        }

        Type[] arguments = parameterizedType.getActualTypeArguments();
        if (arguments.length != 1) {
            return Object.class;
        }

        return arguments[0];
    }

    private static Class<?> rawClass(Type type) {
        if (type instanceof Class<?> clazz) {
            return wrapPrimitive(clazz);
        }

        if (type instanceof ParameterizedType parameterizedType && parameterizedType.getRawType() instanceof Class<?> clazz) {
            return wrapPrimitive(clazz);
        }

        return Object.class;
    }

    private static Class<?> wrapPrimitive(Class<?> type) {
        if (type == int.class) {
            return Integer.class;
        }

        if (type == float.class) {
            return Float.class;
        }

        if (type == double.class) {
            return Double.class;
        }

        if (type == boolean.class) {
            return Boolean.class;
        }

        return type;
    }

    private static final class Entry {
        private Object value;
        private ConfigControl control;

        private Entry(Object value) {
            this.value = value;
        }
    }
}
