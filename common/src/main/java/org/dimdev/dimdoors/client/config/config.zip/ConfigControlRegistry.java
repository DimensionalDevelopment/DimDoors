package org.dimdev.dimdoors.client.config;

import net.minecraft.resources.ResourceKey;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class ConfigControlRegistry {
    private final Map<Class<?>, ConfigControlFactory> factories = new LinkedHashMap<>();

    public static ConfigControlRegistry defaults() {
        ConfigControlRegistry registry = new ConfigControlRegistry();

        registry.register(boolean.class, BooleanControl::new);
        registry.register(Boolean.class, BooleanControl::new);

        registry.register(int.class, TextControl::integer);
        registry.register(Integer.class, TextControl::integer);
        registry.register(float.class, TextControl::floatingPoint);
        registry.register(Float.class, TextControl::floatingPoint);
        registry.register(double.class, TextControl::decimal);
        registry.register(Double.class, TextControl::decimal);

        registry.register(String.class, TextControl::string);
        registry.register(ResourceKey.class, ResourceKeyControl::new);

        return registry;
    }

    public ConfigControlRegistry copy() {
        ConfigControlRegistry copy = new ConfigControlRegistry();
        copy.factories.putAll(this.factories);
        return copy;
    }

    public ConfigControlRegistry register(Class<?> type, ConfigControlFactory factory) {
        this.factories.put(Objects.requireNonNull(type, "type"), Objects.requireNonNull(factory, "factory"));
        return this;
    }

    public ConfigControl create(OptionInfo option) {
        ConfigControlFactory exact = this.factories.get(option.type());
        if (exact != null) {
            return exact.create(this, option);
        }

        if (List.class.isAssignableFrom(option.type())) {
            return CollectionControl.list(this, option);
        }

        if (Set.class.isAssignableFrom(option.type())) {
            return CollectionControl.set(this, option);
        }

        ConfigControlFactory assignable = findAssignableFactory(option.type());
        if (assignable != null) {
            return assignable.create(this, option);
        }

        if (option.type().isEnum()) {
            return new EnumControl(this, option);
        }

        if (ConfigReflection.isExpandableConfigObjectType(option.type())) {
            Object value = option.value();
            if (value != null) {
                return new ObjectControl(this, option);
            }
        }

        return new UnsupportedControl(this, option);
    }

    private ConfigControlFactory findAssignableFactory(Class<?> type) {
        for (Map.Entry<Class<?>, ConfigControlFactory> entry : this.factories.entrySet()) {
            Class<?> registered = entry.getKey();
            if (!registered.isPrimitive() && registered.isAssignableFrom(type)) {
                return entry.getValue();
            }
        }

        return null;
    }
}
