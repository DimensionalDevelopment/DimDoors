package org.dimdev.dimdoors.client.config;

import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public final class ResourceKeyControl extends AbstractConfigControl {
    private String text;
    private EditBox visibleBox;

    public ResourceKeyControl(ConfigControlRegistry registry, OptionInfo option) {
        super(registry, option);
        Object value = option.value();

        if (value instanceof ResourceKey<?> key) {
            this.text = key.location().toString();
        } else {
            this.text = "";
        }
    }

    @Override
    public int rowCount() {
        return 1;
    }

    @Override
    public void addRows(ControlHost host, RowCursor cursor) {
        int y = cursor.next();
        if (!cursor.isVisible(y)) {
            this.visibleBox = null;
            return;
        }

        host.addLabel(this.option.label(host), host.labelX(), y + 6, 0xE0E0E0);

        EditBox editBox = new EditBox(host.font(), host.valueX(), y, host.valueWidth(), 20, this.option.label(host));
        editBox.setValue(this.text);
        editBox.setMaxLength(1024);
        editBox.setResponder(value -> {
            this.text = value;
            host.validateAll();
        });

        this.visibleBox = editBox;
        host.addTooltip(editBox, this.option.tooltipKey());
        host.addWidget(editBox);
    }

    @Override
    public boolean validate() {
        boolean valid = this.text.trim().isEmpty() || ResourceLocation.tryParse(this.text.trim()) != null;

        if (this.visibleBox != null) {
            this.visibleBox.setTextColor(valid ? 0xE0E0E0 : 0xFF5555);
        }

        return valid;
    }

    @Override
    public void commit() {
        String trimmed = this.text.trim();
        ResourceKey<Level> value = trimmed.isEmpty()
                ? null
                : ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(trimmed));
        this.option.setValue(value);
    }
}
