package org.dimdev.dimdoors.client.config;

public abstract class AbstractConfigControl<T> implements ConfigControl<T> {
    protected final ConfigControlRegistry registry;
    protected final OptionInfo option;

    protected AbstractConfigControl(ConfigControlRegistry registry, OptionInfo option) {
        this.registry = registry;
        this.option = option;
    }

    @Override
    public String key() {
        return this.option.key();
    }
}
