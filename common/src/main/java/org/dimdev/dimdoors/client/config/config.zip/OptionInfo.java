package org.dimdev.dimdoors.client.config;

import net.minecraft.network.chat.Component;
import org.dimdev.dimdoors.config.Option;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

public final class OptionInfo<T> {
    private final String key;
    private final Class<?> type;
    private final Type genericType;
    private final Field field;
    private final Object owner;
    private final Option annotation;
    private final Supplier<T> getter;
    private final Consumer<T> setter;
    private final Component labelOverride;
    private final String tooltipKey;

    private OptionInfo(
            String key,
            Class<?> type,
            Type genericType,
            Field field,
            Object owner,
            Option annotation,
            Supplier<T> getter,
            Consumer<T> setter,
            Component labelOverride,
            String tooltipKey
    ) {
        this.key = Objects.requireNonNull(key, "key");
        this.type = Objects.requireNonNull(type, "type");
        this.genericType = genericType == null ? type : genericType;
        this.field = field;
        this.owner = owner;
        this.annotation = annotation;
        this.getter = Objects.requireNonNull(getter, "getter");
        this.setter = Objects.requireNonNull(setter, "setter");
        this.labelOverride = labelOverride;
        this.tooltipKey = tooltipKey == null ? key : tooltipKey;
    }

    public static OptionInfo<?> field(String key, Field field, Object owner, Option annotation) {
        Objects.requireNonNull(field, "field");
        Objects.requireNonNull(owner, "owner");
        field.setAccessible(true);

        return new OptionInfo<>(
                key,
                field.getType(),
                field.getGenericType(),
                field,
                owner,
                annotation,
                () -> readField(key, field, owner),
                value -> writeField(key, field, owner, value),
                null,
                key
        );
    }

    public static OptionInfo value(
            String key,
            Class<?> type,
            Type genericType,
            Supplier<Object> getter,
            Consumer<Object> setter,
            Component labelOverride,
            String tooltipKey
    ) {
        return new OptionInfo(key, type, genericType, null, null, null, getter, setter, labelOverride, tooltipKey);
    }

    public String key() {
        return this.key;
    }

    public Class<?> type() {
        return this.type;
    }

    public Type genericType() {
        return this.genericType;
    }

    public Field field() {
        return this.field;
    }

    public Object owner() {
        return this.owner;
    }

    public Option annotation() {
        return this.annotation;
    }

    public T value() {
        return this.getter.get();
    }

    public void setValue(T value) {
        this.setter.accept(value);
    }

    public Component label(ControlHost host) {
        return this.labelOverride == null ? host.optionLabel(this.key) : this.labelOverride;
    }

    public String tooltipKey() {
        return this.tooltipKey;
    }

    private static Object readField(String key, Field field, Object owner) {
        try {
            field.setAccessible(true);
            return field.get(owner);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Failed to read config option: " + key, e);
        }
    }

    private static void writeField(String key, Field field, Object owner, Object value) {
        try {
            field.setAccessible(true);
            field.set(owner, value);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Failed to write config option: " + key, e);
        }
    }
}
