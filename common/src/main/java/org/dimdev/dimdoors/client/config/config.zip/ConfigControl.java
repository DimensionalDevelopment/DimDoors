package org.dimdev.dimdoors.client.config;

public interface ConfigControl<T> {
    String key();

    int rowCount();

    void addRows(ControlHost host, RowCursor cursor);

    boolean validate();

    void commit();
}
